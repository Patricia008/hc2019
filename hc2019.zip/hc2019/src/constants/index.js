module.exports = {
  files: {
    a: './data/a_example.txt',
    b: './data/b_lovely_landscapes.txt',
    c: './data/c_memorable_moments.txt',
    d: './data/d_pet_pictures.txt',
    e: './data/e_shiny_selfies.txt'
  }
};
